﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CNN_identifikasi_mobil
{
    public partial class cover : Form
    {
        public cover()
        {
            InitializeComponent();
        }

        private void kompresiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
            this.Hide();
        }

        private void cover_Load(object sender, EventArgs e)
        {

        }
    }
}
